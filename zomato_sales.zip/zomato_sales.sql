create database zomato_analysis;
use zomato_analysis;
#zomato analysis project 
use zomato_analysis;
select * from main;
select * from zomato_date;
select * from currency;
select * from country;

#questions
#10 Develop Charts based on Cusines, City, Ratings
SELECT cuisines, city, AVG(rating) AS average_rating
FROM main
GROUP BY cuisines, city;

#9 Percentage of Resturants based on "Has_Online_delivery"
Select 
	concat(round(avg(case when Has_Online_delivery = 'No'
    then 1 
    else 0 end) *100,2),'%') 
    as Has_No_Online_delivery, 
	concat(round(avg(case when Has_Online_delivery = 'Yes' 
    then 1
    else 0 end) *100,2),'%')
    as Has_Online_delivery
FROM main ;

#8 Percentage of Resturants based on "Has_Table_booking"
Select 
	concat(round(avg(case when Has_Table_booking = 'No'
    then 1 
    else 0 end) *100,2),'%') 
    as Has_No_Table_booking, 
	concat(round(avg(case when Has_Table_booking = 'Yes' 
    then 1 else 0 end) *100,2),'%') 
    as Has_Table_booking
FROM main ;

   
#7Create buckets based on Average Price of reasonable size and find out how many resturants falls in each buckets
select * from main;
    WITH BucketedRestaurants AS (
    SELECT 
        NTILE(5) OVER (ORDER BY Average_cost_for_two) AS Bucket,
        Average_cost_for_two
    FROM main
)
SELECT 
    Bucket,
    COUNT(*) AS NumRestaurants
FROM 
    BucketedRestaurants
GROUP BY 
    Bucket;
    
#6 Count of Resturants based on Average Ratings
select*from main;

    SELECT 
    ROUND(AVG(Rating), 1) AS Average_Rating,
    COUNT(*) AS NumRestaurants
FROM 
    main
GROUP BY 
    ROUND(Rating);

    
#1.Build a Data Model using the Sheets in the Excel File

insert into country values(1,"India");
insert into country values(14,"Australia");
insert into country values(30,"Barzil");
insert into country values(37,"Canada");
insert into country values(94,"Indonesia");
insert into country values(148,"New Zealand");
insert into country values(162,"Philippines");
insert into country values(166,"Qatar");
insert into country values(184,"Singapore");
insert into country values(189,"South Africa");
insert into country values(191,"Sri lanka");
insert into country values(208,"Turkey");
insert into country values(214,"UAE");
insert into country values(215,"UK");
insert into country values(216,"USA");

Select * from country;

select * from main;

#3rd Convert the Average cost for 2 column into USD dollars 
select *  from main;
select * from currency;
desc main;
select * from main left join currency on currency = currency.ï»¿Currency;

select currency,USD_rate*Average_Cost_for_two as USD_dollars from main left join currency on currency =currency.ï»¿Currency;


#2Build a Calendar Table using the Columns Datekey_Opening ( Which has Dates from Minimum Dates and Maximum Dates)
CREATE TABLE calender_table (
    Datekey_Opening DATE PRIMARY KEY,
    Year INT,
    Monthno INT,
    Monthfullname VARCHAR(20),
    Quarter VARCHAR(2),
    YearMonth VARCHAR(7),
    Weekdayno INT,
    Weekdayname VARCHAR(20),
    FinancialMonth INT,
    FinancialQuarter INT
);
select * from calender_table;

INSERT INTO calender_table (Datekey_Opening, Year, Monthno, Monthfullname, Quarter, YearMonth, Weekdayno, Weekdayname, FinancialMonth, FinancialQuarter)
SELECT
    Datekey_Opening,
    YEAR(Datekey_Opening),
    MONTH(Datekey_Opening),
    MONTHNAME(Datekey_Opening),
    CONCAT('Q', QUARTER(Datekey_Opening)),
    CONCAT(YEAR(Datekey_Opening), '-', LEFT(MONTHNAME(Datekey_Opening), 3)),
    DAYOFWEEK(Datekey_Opening),
    DAYNAME(Datekey_Opening),
    IF(MONTH(Datekey_Opening) >= 4, MONTH(Datekey_Opening) - 3, MONTH(Datekey_Opening) + 9),
    CEILING((IF(MONTH(Datekey_Opening) >= 4, MONTH(Datekey_Opening) - 3, MONTH(Datekey_Opening) + 9)) / 3.0)
FROM
     calender_table;
     select * from calender_table;

-- 4.Find the Numbers of Resturants based on City and Country.
select city,count(RestaurantID)FROM main group by city;

select CountryName,count(RestaurantID)from main m 
left join country c on m.CountryCode= c.ï»¿Countryid 
group by CountryName;


-- 7.Create buckets based on Average Price of reasonable size and find out how many resturants falls in each buckets
select
	cost_range,
    count(*) As TotalRestaurants
from(
	select
		case
			when Average_cost_for_two between 0 and 300 then "0-300"
            when Average_cost_for_two between 301 and 600 then "301-600"
            when Average_cost_for_two between 601 and 1000 then "601-1000"
            when Average_cost_for_two between 1001 and 4300 then "1001-430000"
            else"Other"
		end as cost_range
	from	
		main
) As Subquery
group by cost_range;

desc main;

